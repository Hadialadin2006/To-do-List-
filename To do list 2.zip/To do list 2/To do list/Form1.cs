using System.Data;
using System.Windows.Forms;

namespace To_do_list
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void ToDoList_Load(object sender, EventArgs e)
        {

        }

        private void textBoxbeschreibung_TextChanged(object sender, EventArgs e)
        {

        }

        private void NewButton_Click(object sender, EventArgs e)
        {
            toDoListView.Rows.Add(textBox1.Text, textBoxbeschreibung.Text, dateTimePicker1.Text);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            toDoListView.CurrentRow.Cells["titel"].Value = textBox1.Text;
            toDoListView.CurrentRow.Cells["beschreibung"].Value = textBoxbeschreibung.Text;
            toDoListView.CurrentRow.Cells["datum"].Value = dateTimePicker1.Text;

        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            int index = toDoListView.CurrentCell.RowIndex;
            toDoListView.Rows.RemoveAt(index);
        }



        private void toDoListView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }
    }
}