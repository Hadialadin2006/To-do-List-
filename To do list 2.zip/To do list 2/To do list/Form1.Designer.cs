﻿namespace To_do_list
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            TitleTextBox = new Label();
            BeschreibungTextbox = new Label();
            textBoxbeschreibung = new TextBox();
            NewButton = new Button();
            button1 = new Button();
            DeleteButton = new Button();
            toDoListView = new DataGridView();
            titel = new DataGridViewTextBoxColumn();
            beschreibung = new DataGridViewTextBoxColumn();
            datum = new DataGridViewTextBoxColumn();
            textBox1 = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)toDoListView).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.FlatStyle = FlatStyle.Popup;
            label3.Font = new Font("Forte", 24F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point);
            label3.ForeColor = Color.Snow;
            label3.ImageAlign = ContentAlignment.MiddleRight;
            label3.Location = new Point(3, -2);
            label3.Name = "label3";
            label3.Size = new Size(1286, 67);
            label3.TabIndex = 6;
            label3.Text = "To do list";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TitleTextBox
            // 
            TitleTextBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            TitleTextBox.Location = new Point(11, 87);
            TitleTextBox.Name = "TitleTextBox";
            TitleTextBox.Size = new Size(1267, 25);
            TitleTextBox.TabIndex = 7;
            TitleTextBox.Text = "Title:";
            // 
            // BeschreibungTextbox
            // 
            BeschreibungTextbox.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            BeschreibungTextbox.Location = new Point(11, 172);
            BeschreibungTextbox.Name = "BeschreibungTextbox";
            BeschreibungTextbox.Size = new Size(1267, 25);
            BeschreibungTextbox.TabIndex = 9;
            BeschreibungTextbox.Text = "Beschreibung";
            // 
            // textBoxbeschreibung
            // 
            textBoxbeschreibung.Location = new Point(11, 200);
            textBoxbeschreibung.Multiline = true;
            textBoxbeschreibung.Name = "textBoxbeschreibung";
            textBoxbeschreibung.Size = new Size(1267, 31);
            textBoxbeschreibung.TabIndex = 10;
            textBoxbeschreibung.TextChanged += textBoxbeschreibung_TextChanged;
            // 
            // NewButton
            // 
            NewButton.BackColor = SystemColors.ActiveCaption;
            NewButton.Font = new Font("Segoe UI", 9F, FontStyle.Italic, GraphicsUnit.Point);
            NewButton.Location = new Point(16, 273);
            NewButton.Name = "NewButton";
            NewButton.Size = new Size(326, 52);
            NewButton.TabIndex = 11;
            NewButton.Text = "Neu";
            NewButton.UseVisualStyleBackColor = false;
            NewButton.Click += NewButton_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveCaption;
            button1.Font = new Font("Segoe UI", 9F, FontStyle.Italic, GraphicsUnit.Point);
            button1.Location = new Point(16, 332);
            button1.Name = "button1";
            button1.Size = new Size(326, 52);
            button1.TabIndex = 13;
            button1.Text = "Edit";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // DeleteButton
            // 
            DeleteButton.BackColor = SystemColors.ActiveCaption;
            DeleteButton.Font = new Font("Segoe UI", 9F, FontStyle.Italic, GraphicsUnit.Point);
            DeleteButton.Location = new Point(16, 390);
            DeleteButton.Name = "DeleteButton";
            DeleteButton.Size = new Size(326, 52);
            DeleteButton.TabIndex = 14;
            DeleteButton.Text = "Löschen";
            DeleteButton.UseVisualStyleBackColor = false;
            DeleteButton.Click += DeleteButton_Click;
            // 
            // toDoListView
            // 
            toDoListView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            toDoListView.BackgroundColor = SystemColors.ActiveCaption;
            toDoListView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            toDoListView.Columns.AddRange(new DataGridViewColumn[] { titel, beschreibung, datum });
            toDoListView.Location = new Point(376, 273);
            toDoListView.Name = "toDoListView";
            toDoListView.RowHeadersWidth = 62;
            toDoListView.RowTemplate.Height = 33;
            toDoListView.Size = new Size(900, 482);
            toDoListView.TabIndex = 16;
            toDoListView.CellContentClick += toDoListView_CellContentClick;
            // 
            // titel
            // 
            titel.HeaderText = "Titel";
            titel.MinimumWidth = 8;
            titel.Name = "titel";
            // 
            // beschreibung
            // 
            beschreibung.HeaderText = "Beschreibung";
            beschreibung.MinimumWidth = 8;
            beschreibung.Name = "beschreibung";
            // 
            // datum
            // 
            datum.HeaderText = "Datum";
            datum.MinimumWidth = 8;
            datum.Name = "datum";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(11, 113);
            textBox1.Margin = new Padding(4, 5, 4, 5);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(1267, 31);
            textBox1.TabIndex = 18;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(17, 470);
            dateTimePicker1.Margin = new Padding(4, 5, 4, 5);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(323, 31);
            dateTimePicker1.TabIndex = 19;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SteelBlue;
            ClientSize = new Size(1291, 831);
            Controls.Add(dateTimePicker1);
            Controls.Add(textBox1);
            Controls.Add(toDoListView);
            Controls.Add(DeleteButton);
            Controls.Add(button1);
            Controls.Add(NewButton);
            Controls.Add(textBoxbeschreibung);
            Controls.Add(BeschreibungTextbox);
            Controls.Add(TitleTextBox);
            Controls.Add(label3);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)toDoListView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label3;
        private Label TitleTextBox;
        private Label BeschreibungTextbox;
        private TextBox textBoxbeschreibung;
        private Button NewButton;
        private Button button1;
        private Button DeleteButton;
        private DataGridView toDoListView;
        private DataGridViewTextBoxColumn titel;
        private DataGridViewTextBoxColumn beschreibung;
        private DataGridViewTextBoxColumn datum;
        private TextBox textBox1;
        private DateTimePicker dateTimePicker1;
    }
}